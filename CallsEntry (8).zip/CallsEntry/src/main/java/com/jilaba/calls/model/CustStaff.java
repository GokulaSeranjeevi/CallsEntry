package com.jilaba.calls.model;

public class CustStaff {

	private String custStaffId;
	private String custStaffName;

	public String getCustStaffId() {
		return custStaffId;
	}

	public void setCustStaffId(String custStaffId) {
		this.custStaffId = custStaffId;
	}

	public String getCustStaffName() {
		return custStaffName;
	}

	public void setCustStaffName(String custStaffName) {
		this.custStaffName = custStaffName;
	}

}
