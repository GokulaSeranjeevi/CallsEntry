package com.jilaba.calls.model;

public class DatabaseName {

	private int DatabaseId;
	private String DatabaseName;

	public int getDatabaseId() {
		return DatabaseId;
	}

	public void setDatabaseId(int databaseId) {
		DatabaseId = databaseId;
	}

	public String getDatabaseName() {
		return DatabaseName;
	}

	public void setDatabaseName(String databaseName) {
		DatabaseName = databaseName;
	}

}
