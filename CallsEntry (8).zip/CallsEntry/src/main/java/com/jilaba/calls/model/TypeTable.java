package com.jilaba.calls.model;

public class TypeTable {

	private String lblName;
	private String lblValue;

	public String getLblName() {
		return lblName;
	}

	public void setLblName(String lblName) {
		this.lblName = lblName;
	}

	public String getLblValue() {
		return lblValue;
	}

	public void setLblValue(String lblValue) {
		this.lblValue = lblValue;
	}

}
