package com.jilaba.calls.common;

public class LoginCredential {
	public static String localIpAdd = "";
	public static String version = "";

	public static String getLocalIpAdd() {
		return localIpAdd;
	}

	public static void setLocalIpAdd(String localIpAdd) {
		LoginCredential.localIpAdd = localIpAdd;
	}

	public static String getVersion() {
		return version;
	}

	public static void setVersion(String version) {
		LoginCredential.version = version;
	}

}
