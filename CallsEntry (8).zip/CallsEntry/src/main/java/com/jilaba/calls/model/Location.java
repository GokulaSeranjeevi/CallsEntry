package com.jilaba.calls.model;

public class Location {

}
