package com.jilaba.calls.common;

import java.text.SimpleDateFormat;
import java.time.format.DateTimeFormatter;

public class CommonValues {
	public static final int MAINSCREEN = 10;

	public static SimpleDateFormat df = new SimpleDateFormat("dd-MMM-yyyy");

}
