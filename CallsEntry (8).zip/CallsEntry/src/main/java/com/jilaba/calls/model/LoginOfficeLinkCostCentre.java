package com.jilaba.calls.model;

public class LoginOfficeLinkCostCentre {
	private String active = "";
	private String compId = "";
	private String costCode = "";
	private int createdBy = 0;
	private String createdDate = "";
	private String createdTime = "";
	private String dataTranflag = "";
	private int sno = 0;
	private String sysGen = "";

	public String getActive() {
		return active;
	}

	public void setActive(String active) {
		this.active = active;
	}

	public String getCompId() {
		return compId;
	}

	public void setCompId(String compId) {
		this.compId = compId;
	}

	public String getCostCode() {
		return costCode;
	}

	public void setCostCode(String costCode) {
		this.costCode = costCode;
	}

	public int getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(int createdBy) {
		this.createdBy = createdBy;
	}

	public String getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedTime() {
		return createdTime;
	}

	public void setCreatedTime(String createdTime) {
		this.createdTime = createdTime;
	}

	public String getDataTranflag() {
		return dataTranflag;
	}

	public void setDataTranflag(String dataTranflag) {
		this.dataTranflag = dataTranflag;
	}

	public int getSno() {
		return sno;
	}

	public void setSno(int sno) {
		this.sno = sno;
	}

	public String getSysGen() {
		return sysGen;
	}

	public void setSysGen(String sysGen) {
		this.sysGen = sysGen;
	}

}
