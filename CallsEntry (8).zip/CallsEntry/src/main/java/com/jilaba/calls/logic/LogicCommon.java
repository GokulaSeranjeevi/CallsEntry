package com.jilaba.calls.logic;

import org.springframework.stereotype.Component;

@Component
public class LogicCommon {
	

}
